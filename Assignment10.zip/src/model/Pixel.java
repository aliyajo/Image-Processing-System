package model;

/**
 * This class is to create a Pixel object.
 * It implements the IPixel Interface.
 */
public class Pixel implements IPixel {
  private int r;
  private int g;
  private int b;

  /**
   * This constructor creates the Pixel constructor given the three components.
   *
   * @param r integer of the red component.
   * @param g integer of the green component.
   * @param b integer of the blue component.
   */
  public Pixel(int r, int g, int b) {
    if (r < 0 || r > 255 || g < 0 || g > 255 || b < 0 || b > 255) {
      throw new IllegalArgumentException("Pixel values out of bounds.");
    }
    this.r = r;
    this.g = g;
    this.b = b;
  }

  @Override
  public int getR() {
    return this.r;
  }

  @Override
  public void setR(int val) {
    if (val < 0 || val > 255) {
      throw new IllegalArgumentException("Channel value is invalid");
    }
    this.r = val;
  }

  @Override
  public int getG() {
    return this.g;
  }

  @Override
  public void setG(int val) {
    if (val < 0 || val > 255) {
      throw new IllegalArgumentException("Channel value is invalid");
    }
    this.g = val;
  }

  @Override
  public int getB() {
    return this.b;
  }

  @Override
  public void setB(int val) {
    if (val < 0 || val > 255) {
      throw new IllegalArgumentException("Channel value is invalid");
    }
    this.b = val;
  }

  @Override
  public String toString() {
    return this.r + " " + this.g + " " + this.b;
  }
}
