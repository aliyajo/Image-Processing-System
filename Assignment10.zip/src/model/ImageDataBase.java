package model;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * This class represents the model for an Image.
 */
public class ImageDataBase implements IImageDataBase {
  private final Map<String, IImageState> images;

  /**
   * This constructor creates new ImageDataBase object.
   */
  public ImageDataBase() {
    this.images = new HashMap<String, IImageState>();
  }

  @Override
  public void add(String id, IImageState image) {
    if (id == null || image == null) {
      throw new IllegalArgumentException("id or image is null");
    }
    this.images.put(id, image);
  }

  @Override
  public IImageState get(String id) {
    Objects.requireNonNull(id);
    return this.images.get(id);
  }

  public Map<String, IImageState> getData() {
    return images;
  }
}
