package model.gui;

/**
 * Created by vidojemihajlovikj on 7/26/23.
 */
public interface IModel {
  String getData();

  void setData(String data);
}
