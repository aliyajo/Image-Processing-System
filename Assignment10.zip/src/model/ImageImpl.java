package model;

/**
 * The class implements an image.
 * This class implements the IImage Interface.
 */
public class ImageImpl implements IImage {
  private final int width;
  private final int height;
  private final IPixel[][] data;

  /**
   * This constructor creates a new image.
   *
   * @param width  integer of the width of the image.
   * @param height integer of the height of the image.
   */
  public ImageImpl(int width, int height) {
    this.width = width;
    this.height = height;
    // Initialize the data array with empty pixels
    this.data = new IPixel[width][height];
  }

  @Override
  public int getHeight() {
    return this.height;
  }

  @Override
  public int getWidth() {
    return this.width;
  }

  @Override
  public int getRedChannel(int x, int y) {
    if (x < 0 || x >= this.width || y < 0 || y >= this.height) {
      throw new IllegalArgumentException("x or y outside of the picture");
    }
    return this.data[x][y].getR();
  }

  @Override
  public int getGreenChannel(int x, int y) {
    if (x < 0 || x >= this.width || y < 0 || y >= this.height) {
      throw new IllegalArgumentException("x or y outside of the picture");
    }
    return this.data[x][y].getG();
  }

  @Override
  public int getBlueChannel(int x, int y) {
    if (x < 0 || x >= this.width || y < 0 || y >= this.height) {
      throw new IllegalArgumentException("x or y outside of the picture");
    }
    return this.data[x][y].getB();
  }

  @Override
  public void setPixel(int x, int y, int r, int g, int b) {
    if (x < 0 || x >= this.width || y < 0 || y >= this.height) {
      throw new IllegalArgumentException("x or y outside of the picture");
    }
    this.data[x][y] = new Pixel(r, g, b);
  }

}
